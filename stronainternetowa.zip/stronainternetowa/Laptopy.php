<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet"> 
<script src="test10.js"></script>
</head>
<body>


<div class="nav">
<img src="logo.png" height="70px" width="200px" align="middle" alt="logofirmy">
<input type="text" id="wyszukiwarka" name="searchbox" placeholder="Wpisz fraze..">
<input type="image" src="lupa.png" height="37px" width="37px" align="center" alt="submit">
<a href="koszyk.php">
<input type="image" src="cartshop.png" height="37px" width="37px" align="center" alt="koszyczek">
<div class="navmenukomponenty">
<ul>
  <li><a href="index.php">Strona Główna</a></li>
  <li><a href="procesory.php">Procesory</a></li>
  <li><a href="pamięci.php">Pamięci RAM</a></li>
  <li><a href="płyty.php">Płyty Główne</a></li>
  <li><a href="zasilacze.php">Zasilacze</a></li>
  <li><a href="obudowy.php">Obudowy</a></li>
  <li><a href="KartyGraficzne.php">Karty Graficzne</a></li>
  <li><a href="myszki.php">Myszki</a></li>
  <li><a href="słuchawki.php">Słuchawki</a></li>
  <li><a href="monitory.php">Monitory</a></li>
  <li><a href="klawiatury.php">Klawiatury</a></li>
  <li><a href="telewizory.php">Telewizory</a></li>
  <li><a href="smartfony.php">Smartfony</a></li>
</ul>
</div>
<div class="navinfo">
 <ul>
  <li><a href="javascript:alert('Logować i Rejestrować się można tylko i wyłącznie na Stronie Głównej!');">Informacje</a></li>
 </ul>
</div>
</div>

<div class="forallinproducts">
<div class="listofproducts">

<div class="napisdolisty">
Procesor:
</div>

<label class="container">i3
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">i5
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">i7
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">ryzen
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<div class="napisdolisty">
Karta Graficzna:
</div>

<label class="container">Dedykowana
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">Zintegrowana
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<div class="napisdolisty">
Przekątna:
</div>

<label class="container">15.6
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">17.3
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">14
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<div class="napisdolisty">
Producent:
</div>

<label class="container">Acer
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">Asus
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">DreamMachines
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">HP
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">Lenovo
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">Manta
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">Msi
  <input type="checkbox">
  <span class="checkmark"></span>
</label>


</div>

</div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
<div id="banerprom"></div>
</div>



<div class="footer">
  Preware.com to jeden z największych i najpopularniejszych sklepów komputerowych w Polsce. W szerokiej ofercie sklepu można znaleźć wysokiej klasy laptopy, komputery na każdą kieszeń, wydajne podzespoły komputerowe oraz urządzenia peryferyjne. Szeroka oferta urządzeń, akcesoriów i podzespołów umożliwia skonfigurowanie i zakup komputerów o optymalnej wydajności i atrakcyjnej cenie. W asortymencie sklepu nie brak również sprzętów dla graczy – to ergonomiczne i precyzyjne myszki i klawiatury, wysokiej klasy słuchawki, wydajne karty graficzne, nowoczesne procesory i komfortowe fotele gamingowe. Szeroka oferta produktów i ich bardzo duża dostępność to kwestie, które sprawiają, że zakupy są szybkie i wygodne, a na zamówione sprzęty i akcesoria komputerowe nie trzeba długo czekać.
</div>




</body>
</html>