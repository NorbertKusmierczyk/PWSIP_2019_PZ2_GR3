var images = ["208.jpg","209.jpg","210.jpg","211.jpg","212.jpg","213.jpg","214.jpg","215.jpg","216.jpg","217.jpg","218.jpg","219.jpg","220.jpg","221.jpg","222.jpg","223.jpg","224.jpg","225.jpg","226.jpg","227.jpg","228.jpg","229.jpg","230.jpg","231.jpg"];

function list(){
	
	var div = "";
	
	for(var i=0; i<24; i++){
		
		div += '<div style="margin:20px 0px 0px 0px; height: 240px; color: red; position:relative;"><div style="position: absolute; top:1%; left: 2%;"><img width="200"; height="200"; src="'+images[i]+'"/></div><div style="position: absolute; left:45%; top:40%"><a href = "dodaj.php?id='+i+'">produkt</a></div></div>';
		
		
	}
	document.getElementById("banerprom").innerHTML = div;
}


window.onload = list;