﻿
<?php

	session_start();

	if(isset($_POST['login']))
	{
		$isValidate=true;
		
		//nickname
		$login=$_POST['login'];
		if(strlen($login)<5 || (strlen($login)>10))
		{
			$isValidate=false;
			$_SESSION['errorLogin']="Login musi zawierac od 5 do 10 znaków";
		}
		if(ctype_alnum($login)==false)
		{
			$isValidate=false;
			$_SESSION['errorLogin']="Login musi zawierać litery i cyfry";
		}
		
		$email = $_POST['email'];
		$sanit = filter_var($email, FILTER_SANITIZE_EMAIL);
		
		if(filter_var($sanit,FILTER_VALIDATE_EMAIL)==false || $sanit!=$email)
		{
			$isValidate=false;
			$_SESSION['errorEmail']="Niepoprawny adress e-mail";
		}
		
		$pass1 = $_POST['password1'];
		$pass2 = $_POST['password2'];
		
		if(strlen($pass1)<8 || strlen($pass1)>100)
		{
			  $isValidate=false;
			  $_SESSION['errorPassword']="Hasło musi zawierać od 8 do 15 znaków";
		}
		
		if($pass1!=$pass2)
		{
			$isValidate=false;
			$_SESSION['errorPassword']="Hasła nie sa identyczne";
		}
		
		$hash = password_hash($pass1, PASSWORD_BCRYPT);
		
		if(!isset($_POST['regulamin']))
		{
			$isValidate=false;
			$_SESSION['errorRegulamin']="Potwierdź regulamin";
		}
		
		//$captchaKey = "6LdykIsUAAAAAPVBGwxAJF-VmrwAkBp5t60BuO3E";
		
		//$checkKey = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret='.$captchaKey.'&response='.$_POST['g-recaptcha-response']);
		
		//$res = json_decode($checkKey);
		
		//if($res->success==false)
		//{
			
		//	$_SESSION['errorCap']="Potwierdź, że jesteś człowiekiem";
		//}
		
		require_once "connect.php";
		
		try{
			
			$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
	
			if($polaczenie->connect_errno!=0)
			{
				$_SESSION['errorRegulamin']="Error: ".$polaczenie->connect_errno;
			}
			else{
				
				$rezultat = $polaczenie->query("select id from users where log='$login'");
				
				if(!$rezultat) throw new Exception($polaczenie->error);
				
				$ilosc = $rezultat->num_rows;
				
				if($ilosc > 0)
				{
					$isValidate=false;
					$_SESSION['errorLogin']="Istnieje już taki użytkownik";
				}
				
				
				$polaczenie->close();
			}
			
			if($isValidate==true)
			{
				
				$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
				$rezultat = $polaczenie->query("Insert into users values(null, '$login', '$email', '$hash')");
				
				if(!$rezultat)
				{
					throw new Exception($polaczenie->error);
				}else{
				
					$_SESSION['rs']=true;
					header('Location: welcome.php');
				}
				$polaczenie->close();
			}
		}catch(Exception $e){
			$m_SESSION['errorLogin']="blad".$e->err;
		}
		

	}

?>


<!DOCTYPE HTML>

<html>

<head>

	<meta charset = "utf-8" />
	<title>PreWare.com</title>
	<!--<link rel = "stylesheet" href = "style.css">-->
	<link rel = "stylesheet" href = "loginSideCSS.css">
	<link rel = "icon" href = "C:\Users\groun\Desktop\icon.ico">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
	<script type = "text/javascript" src = "jquery-3.3.1.min.js"></script>
	<script type = "text/javascript" src = "menu.js"></script>
	<script type = "text/javascript" src = "slid.js"></script>
	<script src='https://www.google.com/recaptcha/api.js'></script>

</head>

<body>

	
	<div class = "logo">
		
			<div class = "header">
			
				<img src = "logo.png" style = "float: left;">
				
			</div>
			
			<div class = "zaloguj">
			
			<a href = "#"></a>
			</div>
			
		
		</div>
		
		<div class = "menu">
		
			<ol>
			
				<li><a href = "index.php">Strona Główna</a></li>
				<li><a href = "loginSide.php">Zaloguj</a></li>
				<div style = "clear: both;"></div>
			
			</ol>
		
		</div>
		
		<div class = "container">
		

			<div class = "content">

				<h2>REJESTRACJA<h2>

				<div class = "contentBox">
				
				<form method = "post">
				
				<p>Nazwa użytkownika</p>
				<input type = "text" name = "login"/>
				
<div id = "errorId">
	
<?php

	if(isset($_SESSION['errorLogin']))
	{ 
		echo $_SESSION['errorLogin'];
		unset($_SESSION['errorLogin']);
	}

?>

</div>
		
				
				<p>E-mail</p>
				<input type = "text" name = "email"/>
				
<div id = "errorId" style="top: 24%;">
	
<?php

	if(isset($_SESSION['errorEmail']))
	{ 
		echo $_SESSION['errorEmail'];
		unset($_SESSION['errorEmail']);
	}

?>

</div>
				
				<p>Haslo</p>
				<input type = "password" name = "password1"/>
				 
<div id = "errorId" style="top: 35%;">
	
<?php

	if(isset($_SESSION['errorPassword']))
	{ 
		echo $_SESSION['errorPassword'];
		unset($_SESSION['errorPassword']);
	}

?>

</div>
				
				<p>Powtórz hasło</p>
				<input type = "password" name = "password2"/>
				<br /><br />
				<label><input type = "checkbox" name = "regulamin">Regulamin</label>
				
<div id = "errorId" style="top: 51%;">
	
<?php

	if(isset($_SESSION['errorRegulamin']))
	{ 
		echo $_SESSION['errorRegulamin'];
		unset($_SESSION['errorRegulamin']);
	}

?>

</div>
				<br /><br />
				
				 
<div id = "errorId" style="top: 60%;">
	
<?php

	if(isset($_SESSION['errorCap']))
	{ 
		echo $_SESSION['errorCap'];
		unset($_SESSION['errorCap']);
	}

?>

</div>
				<br />
				<input type = "submit" value = "Login" />
				
				</form>
				<br></br>
				
				
				</div>
					
		
			</div>
	
	
	</div>


</body>


</body>

</html>