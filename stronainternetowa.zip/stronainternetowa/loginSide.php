﻿
<?php
	
	session_start();

?>

<!DOCTYPE HTML>

<html>

<head>

	<meta charset = "utf-8" />
	<title>PreWare.com</title>
	<!--<link rel = "stylesheet" href = "style.css">-->
	<link rel = "stylesheet" href = "loginSideCSS.css">
	<link rel = "icon" href = "C:\Users\groun\Desktop\icon.ico">
	<script type = "text/javascript" src = "jquery-3.3.1.min.js"></script>
	<script type = "text/javascript" src = "menu.js"></script>
	<script type = "text/javascript" src = "slid.js"></script>

</head>

<body>

	
	<div class = "logo">
		
			<div class = "header">
			
				<img src = "logo.png" style = "float: left;">
				
				
			</div>
			
			<div class = "zaloguj">
			
			<a href = "#"></a>
			</div>
			
		
		</div>
		
		<div class = "menu">
		
			<ol>
			
				<li><a href = "index.php">Strona główna</a></li>
				
				<li><a href = "logout.php">Zaloguj</a></li>
	
				<div style = "clear: both;"></div>
			
			</ol>
		
		</div>
		
		<div class = "container">
		

			<div class = "content">

				<h2>LOGIN<h2>

				<div class = "contentBox">
				
				<form action = "logIn.php" method = "post">
				<p>Nazwa uzytkownika</p>
				<input type = "text" name = "login"/>
				<p>Haslo</p>
				<input type = "password" name = "password"/>
				<br></br>
				<input type = "submit" value = "Login" />
				</form>
				<br></br>
				<p>
				Nie masz jeszcze konta? Kliknij <a href = "registerSide.php">tutaj</a>, aby się zarejestrować.
				</p>
				
				</div>
				
<div id = "errorId">
	
<?php

	if(isset($_SESSION['blad']))
	{
		echo $_SESSION['blad'];
		unset($_SESSION['blad']);
	}

?>

</div>
			
		
			</div>
	
	
	</div>


</body>


</body>

</html>