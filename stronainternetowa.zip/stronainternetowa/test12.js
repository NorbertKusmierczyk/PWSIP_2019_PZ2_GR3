var images = ["257.jpg","258.jpg","259.jpg","260.jpg","261.jpg","262.jpg","263.jpg","264.jpg","265.jpg","266.jpg","267.jpg","268.jpg","269.jpg","270.jpg","271.jpg","272.jpg","273.jpg","274.jpg","275.jpg","276.jpg","277.jpg"];

function list(){
	
	var div = "";
	
	for(var i=0; i<21; i++){
		
		div += '<div style="margin:20px 0px 0px 0px; height: 240px; color: red; position:relative;"><div style="position: absolute; top:1%; left: 2%;"><img width="200"; height="200"; src="'+images[i]+'"/></div><div style="position: absolute; left:45%; top:40%"><a href = "#">produkt</a></div></div>';
		
		
	}
	document.getElementById("banerprom").innerHTML = div;
}


window.onload = list;