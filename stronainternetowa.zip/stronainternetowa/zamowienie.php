

<?php

	session_start();
	
	require_once "connect.php";
	
	$buff = array();
	
	//if($_POST['backCard']){
		//header('Location: orderDetailsSite.php');
		//exit();
	//}
	
	
	$type = $_POST['dostawa'];
	
	$_SESSION['lastOrderPage'] = false;


	$buff = $_SESSION['buff'];

	//print_r($buff);
	
	
	$connect = @new mysqli($host, $db_user, $db_password, $db_name);
	
	
	foreach($buff as $i => $element){

	$id = $_SESSION['idUser'];
	$user = $element['user'];
	$productIdentity = $element['idProduktu'];
	$name = $element['name'];
	$imie = $element['imie'];
	$nazwisko = $element['nazwisko'];
	$email = $element['email'];
	$select = $element['select'];
	$kod = $element['kod'];
	$adres = $element['adres'];
	$numerDomu = $element['numerDomu'];
	$ilosc = $element['ilosc'];
	$cena = $element['price']*$element['ilosc'];
	$date = date('Y-m-d H:i:s');
	
	$query = "INSERT INTO orders(id,user,imie, nazwisko, email, miasto, kod, adres, numerDomu, idProduktu, name, ilosc,cena,dostawa, dataZamowienia) 
	values($id,'$user','$imie','$nazwisko','$email','$select','$kod','$adres','$numerDomu', $productIdentity,'$name',$ilosc,$cena,'$type', '$date')";

	$result = mysqli_query($connect, $query);
	
	$sql = sprintf("select amount from products where name='%s'", $element['name']);
			if($rezultat = @$connect->query($sql)){
				$wiersz = $rezultat->fetch_assoc();
				if($wiersz['amount'] > 0 && (($wiersz['amount'] - $element['ilosc']) > 0)){
					$am = $wiersz['amount'] - $element['ilosc'];
					$sqlUpdate = sprintf("update products set amount = '%d' where name = '%s'", $am, $element['name']);
					@$connect->query($sqlUpdate);
				}
			}
	
	}
	$connect->close();
	//print_r($buff);
	unset($buff);
	unset($_SESSION['buff']);
	unset($type);
	
	header('Location: lastOrderPage.php');

?>