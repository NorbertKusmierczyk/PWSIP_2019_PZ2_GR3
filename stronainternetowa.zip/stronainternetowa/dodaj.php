

<?php

	session_start();
	
	require_once "connect.php";
	
	$buff = array();
	
	$identity = $_GET['id'];
	
	if(isset($_SESSION['buff']))
		$buff = $_SESSION['buff'];

	if(!empty($_POST)){
		$buff[] = array('id' => $$_SESSION['idUser'], 'user' => $_SESSION['user'], 'imie' => 0, 'nazwisko' => 0, 'email' => 0, 'select' => 0,'kod' => 0, 'adres' => 0,'numerDomu' => 0, 'idProduktu' => 0, 'name' => $_SESSION['user'], 'price' => 0, 'ilosc' => $_SESSION['amount']);
	}

	$_SESSION['buff'] = $buff;
	
	
	$connect = @new mysqli($host, $db_user, $db_password, $db_name);
	
	$identity = $_GET['id'];
	
	$_SESSION['item'] = $identity;
	
	$query = "select * from products where id=".$identity."";

	$rezult = mysqli_query($connect, $query);
	
	if($rezult->num_rows > 0){

		$wiersz = $rezult->fetch_assoc();
		
		//echo $wiersz['name'].' '.$wiersz['price'].'	'.$user;
		///$buff['id']['user'] = $user;
		//$buff['id']['name'] = $wiersz['name'];
		//$buff['id']['price'] = $wiersz['price'];
		//$buff[] = array('id' => $_GET['id'], 'user' => $_SESSION['user'], 'name' => $wiersz['name'], 'price' => $wiersz['price'], 'ilosc' => $_SESSION['amount']);
		$buff[] = array('id' => $_SESSION['idUser'], 'user' => $_SESSION['user'], 'imie' => 0, 'nazwisko' => 0, 'email' => 0, 'select' => 0,'kod' => 0, 'adres' => 0,'numerDomu' => 0, 'idProduktu' => $wiersz['id'],'name' => $wiersz['name'], 'price' => $wiersz['price'], 'ilosc' => 1);
		
	}else
		echo "erra";
	
	$connect->close();
	$_SESSION['buff'] = $buff;
	print_r($buff);
	//unset($buff);
	//unset($_SESSION['buff']);

 
	header('Location: kosz.php');

?>