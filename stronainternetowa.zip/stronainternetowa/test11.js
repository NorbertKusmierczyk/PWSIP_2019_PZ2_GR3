var images = ["232.jpg","233.jpg","234.jpg","235.jpg","236.jpg","237.jpg","238.jpg","239.jpg"."240.jpg","241.jpg","242.jpg","243.jpg","244.jpg","245.jpg","246.jpg","247.jpg","248.jpg","249.jpg","250.jpg","251.jpg","252.jpg","253.jpg","254.jpg","255.jpg","256.jpg"];

function list(){
	
	var div = "";
	
	for(var i=0; i<25; i++){
		
		div += '<div style="margin:20px 0px 0px 0px; height: 240px; color: red; position:relative;"><div style="position: absolute; top:1%; left: 2%;"><img width="200"; height="200"; src="'+images[i]+'"/></div><div style="position: absolute; left:45%; top:40%"><a href = "#">produkt</a></div></div>';
		
		
	}
	document.getElementById("banerprom").innerHTML = div;
}


window.onload = list;