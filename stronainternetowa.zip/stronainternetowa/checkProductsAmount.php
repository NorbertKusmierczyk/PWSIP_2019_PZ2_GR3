<?php

	$buff = array();
	session_start();
	
	 
	if(isset($_SESSION['buff']))
		$buff = $_SESSION['buff'];
	
	if(empty($buff)){
		$_SESSION['errorZamowienie']="Nie wybrano zadnego produktu";
		unset($_SESSION['zamowienie']);
		header('Location: kosz.php');
	}
	
	$_SESSION['koszButton'] = 5;

	
	require_once "connect.php";
 
 $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
	
	if($polaczenie->connect_errno!=0)
	{
		echo "Error: ".$polaczenie->connect_errno;
	}
	else{
		
		foreach($buff as $i => $element){
			
			$sql = sprintf("select amount from products where name='%s'", $element['name']);
			if($rezultat = @$polaczenie->query($sql)){
				$wiersz = $rezultat->fetch_assoc();
				if($wiersz['amount'] > 0 && (($wiersz['amount'] - $element['ilosc']) > 0)){
					header('Location: orderDetailsSite.php');
				}else{
					$_SESSION['errorZamowienie']="Brakuje towaru w magazynie";
					header('Location: kosz.php');
				}
			}else{
				$_SESSION['errorZamowienie']="Nie można znaleźć produktu";
				header('Location: kosz.php');
			}
		}
		$polaczenie->close();
	}
 	


?>