<br />
<b>Warning</b>:  Unknown: Input variables exceeded 1000. To increase the limit change max_input_vars in php.ini. in <b>Unknown</b> on line <b>0</b><br />
<br />
<b>Warning</b>:  Unknown: Input variables exceeded 1000. To increase the limit change max_input_vars in php.ini. in <b>Unknown</b> on line <b>0</b><br />
﻿
<?php

	session_start();
	
	if(!isset($_POST['login']) || !isset($_POST['password']))
	{
		header('Location: index.php');
		exit();
	}

	require_once "connect.php";
	
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
	
	if($polaczenie->connect_errno!=0)
	{
		echo "Error: ".$polaczenie->connect_errno;
	}
	else{

	$login = $_POST['login'];
	$password = $_POST['password'];
	
	$login = htmlentities($login, ENT_QUOTES, "UTF-8");
	
	$sql = sprintf("select * from Users where log='%s'",
	mysqli_real_escape_string($polaczenie, $login));
	
	if($rezultat = @$polaczenie->query($sql))
	{
		$ilu = $rezultat->num_rows;
		
		if($ilu > 0)
		{
			$wiersz = $rezultat->fetch_assoc();
			
			if(password_verify($password,$wiersz['password']))
			{
				$_SESSION['zalogowany'] = true;
				
				$_SESSION['user'] = $wiersz['log'];
				
				
				unset($_SESSION['blad']);
				$rezultat->close();
				header('Location: zalogowany.php');
			}else{
			
				$_SESSION['blad'] = '<span style="color: red;">Nieprawidłowy login lub hasło</span>';
				header('Location: loginSide.php');
			
				}
		}
		else{
			
			$_SESSION['blad'] = '<span style="color: red;">Nieprawidłowy login lub hasło</span>';
			header('Location: loginSide.php');
		}
		
	}
	
	$polaczenie->close();
	
	}

?>