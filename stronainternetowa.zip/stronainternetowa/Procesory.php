<?php 

  //$buff = array();
  session_start();
  
  $buff[] = array('name' => 0, 'price' => 0);
  
  require_once "connect.php";
  
  $polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
  

  
  if($polaczenie->connect_errno!=0)
  {
    echo "Error: ".$polaczenie->connect_errno;
    header('Location: kosz.php');
  }
  else{
    
    for($i = 1; $i < 304; $i++){
      
      $sql = sprintf("select name, price from products where id='%d'", $i);
      
      if($rezultat = @$polaczenie->query($sql)){
        
        $wiersz = $rezultat->fetch_assoc();
        $buff[$i]['name'] = $wiersz['name'];
        $buff[$i]['price'] = $wiersz['price'];
      
      }
    }
    $polaczenie->close();
  }
  $_SESSION['products'] = $buff;
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet"> 
<script src="test5.js"></script>
</head>
<body>


<div class="nav">
<img src="logo.png" height="70px" width="200px" align="middle" alt="logofirmy">
<input type="text" id="wyszukiwarka" name="searchbox" placeholder="Wpisz fraze..">
<input type="image" src="lupa.png" height="37px" width="37px" align="center" alt="submit">
<a href="koszyk.php">
<input type="image" src="cartshop.png" height="37px" width="37px" align="center" alt="koszyczek">
<div class="navmenukomponenty">
<ul>
  <li><a href="index.php">Strona Główna</a></li>
  <li><a href="klawiatury.php">Klawiatury</a></li>
  <li><a href="pamięci.php">Pamięci RAM</a></li>
  <li><a href="płyty.php">Płyty Główne</a></li>
  <li><a href="zasilacze.php">Zasilacze</a></li>
  <li><a href="obudowy.php">Obudowy</a></li>
  <li><a href="KartyGraficzne.php">Karty Graficzne</a></li>
  <li><a href="myszki.php">Myszki</a></li>
  <li><a href="słuchawki.php">Słuchawki</a></li>
  <li><a href="monitory.php">Monitory</a></li>
  <li><a href="laptopy.php">Laptopy</a></li>
  <li><a href="telewizory.php">Telewizory</a></li>
  <li><a href="smartfony.php">Smartfony</a></li>
</ul>
</div>
<div class="navinfo">
 <ul>
  <li><a href="javascript:alert('Logować i Rejestrować się można tylko i wyłącznie na Stronie Głównej!');">Informacje</a></li>
 </ul>
</div>
</div>

<div class="forallinproducts">
<div class="listofproducts">

<div class="napisdolisty">
Socket:
</div>

<label class="container">FM2+
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">LGA 1151
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">LGA 1151(Coffee Lake)
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">AM4
  <input type="checkbox">
  <span class="checkmark"></span>
</label class="container">
<label class="container">AM3+
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<div class="napisdolisty">
Linia:
</div>

<label class="container">i3
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">i5
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">i7
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">ryzen 3
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">ryzen 5
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">ryzen 7
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">athlon
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">FX
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">pentium
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">celeron
  <input type="checkbox">
  <span class="checkmark"></span>
</label>

<div class="napisdolisty">
Ilosc rdzeni:
</div>

<label class="container">2
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">4
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">6
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">8
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">12
  <input type="checkbox">
  <span class="checkmark"></span>
</label>
<label class="container">16
  <input type="checkbox">
  <span class="checkmark"></span>
</label>



</div>

</div>
<?php foreach($buff as $i => $element){ ?>
 
  <?php if($i != 0) { ?>
  
  <?php echo '<div style="height: 200px; color: white; position:relative;  width:1400px; float:right;  margin: 10px 0px 0px 30px; background-color: #111;">
          <div style="position: absolute; top:5%; left: 2%;">
            
          </div>
          <div style="position: absolute; top: 6%; left: 15%;">
            <h2>'. $element['name'] .'</h2>
            <h2>'. $element['price'] .'</h2>
            <a href = "dodaj.php?id='.$i.'">kup </a>
          </div>
        </div>';?>
  
  <?php } ?>
  
<?php } ?>
</div>



<div class="footer">
  Preware.com to jeden z największych i najpopularniejszych sklepów komputerowych w Polsce. W szerokiej ofercie sklepu można znaleźć wysokiej klasy laptopy, komputery na każdą kieszeń, wydajne podzespoły komputerowe oraz urządzenia peryferyjne. Szeroka oferta urządzeń, akcesoriów i podzespołów umożliwia skonfigurowanie i zakup komputerów o optymalnej wydajności i atrakcyjnej cenie. W asortymencie sklepu nie brak również sprzętów dla graczy – to ergonomiczne i precyzyjne myszki i klawiatury, wysokiej klasy słuchawki, wydajne karty graficzne, nowoczesne procesory i komfortowe fotele gamingowe. Szeroka oferta produktów i ich bardzo duża dostępność to kwestie, które sprawiają, że zakupy są szybkie i wygodne, a na zamówione sprzęty i akcesoria komputerowe nie trzeba długo czekać.
</div>




</body>
</html>