var images = ["90.jpg","91.jpg","92.jpg","93.jpg","94.jpg","95.jpg","96.jpg","97.jpg","98.jpg","99.jpg","100.jpg","101.png","102.jpg","103.jpg","104.jpg","105.jpg","106.jpg","107.jpg","108.jpg","109.jpg","110.jpg","111.jpg","112.jpg","113.jpg","114.jpg","115.jpg"];

function list(){
	
	var div = "";
	
	for(var i=0; i<26; i++){
		
		div += '<div style="margin:20px 0px 0px 0px; height: 240px; color: red; position:relative;"><div style="position: absolute; top:1%; left: 2%;"><img width="200"; height="200"; src="'+images[i]+'"/></div><div style="position: absolute; left:45%; top:40%"><a href = "#">produkt</a></div></div>';
		
		
	}
	document.getElementById("banerprom").innerHTML = div;
}


window.onload = list;