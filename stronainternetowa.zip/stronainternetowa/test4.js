var images = ["72.jpg","73.jpg","74.jpg","75.jpg","76.jpg","77.jpg","78.jpg","79.jpg","80.jpg","81.jpg","82.jpg","83.jpg","84.jpg","85.jpg","86.jpg","87.jpg","88.jpg","89.jpg"];

function list(){
	
	var div = "";
	
	for(var i=0; i<18; i++){
		
		div += '<div style="margin:20px 0px 0px 0px; height: 240px; color: red; position:relative;"><div style="position: absolute; top:1%; left: 2%;"><img width="200"; height="200"; src="'+images[i]+'"/></div><div style="position: absolute; left:45%; top:40%"><a href = "#">produkt</a></div></div>';
		
		
	}
	document.getElementById("banerprom").innerHTML = div;
}


window.onload = list;