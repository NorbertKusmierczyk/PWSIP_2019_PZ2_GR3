<?php

	$buff = array();
	session_start();

	 
	if(isset($_SESSION['buff']))
		$buff = $_SESSION['buff'];
	
	//print_r($buff);
	
	$_SESSION['buff'] = $buff;
	
	if($_POST['backCard']){
		header('Location: kosz.php');
		exit();
	}
	
	
	
	if(isset($_SESSION['buff']))
	{
		$isValidate=true;
		
		//nickname
		$login=$_POST['imie'];
		if(strlen($login)<3 || (strlen($login)>12))
		{	
			$isValidate=false;
			$_SESSION['errorImie']="Imie musi zawierac od 3 do 12 znaków";
		}
		
		if(ctype_alpha($login)==false)
		{
			$isValidate=false;
			$_SESSION['errorImie']="Login musi zawierać tylko litery";
		}
		
		$nazwisko=$_POST['nazwisko'];
		if(strlen($nazwisko)<3 || (strlen($nazwisko)>15))
		{
			$isValidate=false;
			$_SESSION['errorNazwisko']="Nazwisko musi zawierac od 3 do 12 znaków";
		}
		if(ctype_alpha($nazwisko)==false)
		{
			$isValidate=false;
			$_SESSION['errorNazwisko']="Nazwisko musi zawierać litery";
		}
		
		$email = $_POST['email'];
		$sanit = filter_var($email, FILTER_SANITIZE_EMAIL);
		
		if(filter_var($sanit,FILTER_VALIDATE_EMAIL)==false || $sanit!=$email)
		{
			$isValidate=false;
			$_SESSION['errorEmail']="Niepoprawny adress e-mail";
		}
		
		
		$select = $_POST['select'];
		$kod = $_POST['kodPocztowy'];
		$adres = $_POST['adres'];
		$numerDomu = $_POST['numerDomu'];
		
		if(empty($select)){
			$isValidate=false;
			$_SESSION['errorSelect']="Nie wybrano żadnegoo miasta";

		}
		
		if(ctype_alpha($adres)==false){
			$isValidate=false;
			$_SESSION['errorAdres']="Niepoprawny adress";
		}
		
		if(empty($numerDomu)){
			$isValidate=false;
			$_SESSION['errorAdres']="Niepoprawny adress";
		}
		
		
		if(!isset($_POST['regulamin']))
		{
			$isValidate=false;
			$_SESSION['errorRegulamin']="Potwierdź regulamin";
		}
		
		
		
	if($isValidate)
	{
		
	
		foreach($buff as $i => $element){
			$buff[$i]['imie'] = $_SESSION['idUser'];
			$buff[$i]['imie'] = $login;
			$buff[$i]['nazwisko'] = $nazwisko;
			$buff[$i]['email'] = $email;
			$buff[$i]['select'] = $select;
			$buff[$i]['kod'] = $kod;
			$buff[$i]['adres'] = $adres;
			$buff[$i]['numerDomu'] = $numerDomu;
			
		}
 	
		$_SESSION['dostawaIzaplata'] = 0;
		$_SESSION['buff'] = $buff;
		header('Location: dostawaIzaplata.php');
		
	}else{ header('Location: orderDetailsSite.php'); }

	}
	//print_r($buff);
?>