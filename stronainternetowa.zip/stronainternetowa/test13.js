var images = ["278.jpg","279.jpg","280.jpg","281.jpg","282.jpg","283.jpg","284.jpg","285.jpg","286.jpg","287.jpg","288.jpg","289.jpg","290.jpg","291.jpg","292.jpg","293.jpg","294.png","295.png","296.jpg","297.jpg","298.jpg","299.jpg","300.jpg","301.jpg","302.jpg","303.jpg","304.jpg"];

function list(){
	
	var div = "";
	
	for(var i=0; i<27; i++){
		
		div += '<div style="margin:20px 0px 0px 0px; height: 240px; color: red; position:relative;"><div style="position: absolute; top:1%; left: 2%;"><img width="200"; height="200"; src="'+images[i]+'"/></div><div style="position: absolute; left:45%; top:40%"><a href = "#">produkt</a></div></div>';
		
		
	}
	document.getElementById("banerprom").innerHTML = div;
}


window.onload = list;