var images = ["116.png","117.jpg","118.jpg","119.jpg","120.jpg","121.jpg","122.jpg","123.jpg","124.jpg","125.jpg","126.jpg","127.jpg","128.jpg","129.jpg","130.jpg","131.jpg","132.jpg","133.jpg","134.jpg","135.jpg","136.jpg"];

function list(){
	
	var div = "";
	
	for(var i=0; i<21; i++){
		
		div += '<div style="margin:20px 0px 0px 0px; height: 240px; color: red; position:relative;"><div style="position: absolute; top:1%; left: 2%;"><img width="200"; height="200"; src="'+images[i]+'"/></div><div style="position: absolute; left:45%; top:40%"><a href = "#">produkt</a></div></div>';
		
		
	}
	document.getElementById("banerprom").innerHTML = div;
}


window.onload = list;