


var images = ["1.jpg","2.jpg","3.jpg","4.jpg","5.jpg","6.png","7.png","8.png","9.jpg","10.jpg","11.jpg","12.jpg","13.png","14.jpg","15.jpg","16.png","17.jpg","18.jpg","19.jpg","20.jpg","21.jpg","22.jpg","23.jpg","24.jpg","25.jpg","26.jpg"];

function list(){
	
	var div = "";
	
	for(var i=0; i<26; i++){
		
		div += '<div style="margin:20px 0px 0px 0px; height: 240px; color: red; position:relative;"><div style="position: absolute; top:1%; left: 2%;"><img width="200"; height="200"; src="'+images[i]+'"/></div><div style="position: absolute; left:45%; top:40%"><a href = "#">produkt</a></div></div>';
		
		
	}
	document.getElementById("banerprom").innerHTML = div;
}


window.onload = list;