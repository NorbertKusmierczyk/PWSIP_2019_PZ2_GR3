﻿
<?php
	
	$buff = array();
	session_start();
	 
	if(isset($_SESSION['buff']))
		$buff = $_SESSION['buff'];
	
	
	if(!empty($_POST)){
		$buff[] = array('id' => $$_SESSION['idUser'], 'user' => $_SESSION['user'], 'imie' => 0, 'nazwisko' => 0, 'email' => 0, 'select' => 0,'kod' => 0, 'adres' => 0,'numerDomu' => 0, 'idProduktu' => 0, 'name' => $_SESSION['user'], 'price' => 0, 'ilosc' => $_SESSION['amount']);
		//$buff[] = array('id' => $$_SESSION['idUser'], 'user' => $_SESSION['user'], 'imie' => 0, 'nazwisko' => 0, 'email' => 0, 'select' => 0,'kod' => 0, 'adres' => 0,'numerDomu' => 0,'name' => 0, 'price' => 0, 'ilosc' => $_SESSION['amount']);
	}

	$_SESSION['buff'] = $buff;
	
	//header('Location: CardTest.php');

?>

<!DOCTYPE HTML>

<html>

<head>

	<meta charset = "utf-8" />
	<title>PreWare.com</title>
	<!--<link rel = "stylesheet" href = "style.css">-->
	<link rel = "stylesheet" href = "loginSideCSS.css">
	<link rel = "icon" href = "C:\Users\groun\Desktop\icon.ico">
	<script type = "text/javascript" src = "jquery-3.3.1.min.js"></script>
	<script type = "text/javascript" src = "menu.js"></script>
	<script type = "text/javascript" src = "slid.js"></script>
	
	<style>
	table, th, td {
	  border: 1px solid white;
	  color: white;
	  text-align: center;
	}
	table a{
		color: white;
		text-decoration: none;
	}
	table{
		margin-left: 20%;
	}
	input[type = submit]
	{
	width: 20%;
	margin-top: 2%;
	margin-left: 17%;
	padding: 10px;
	position: absolute;
	cursor: pointer;
	color: blue;
	border: none;
	background-color: #664f41;
	}
	</style>

</head>

<body>

	
	<div class = "logo">
		
			<div class = "header">
			
				<img src = "logo.png">
				
				
			</div>
			
			<div class = "zaloguj">
			
			<a href = "#"></a>
			</div>
			
		
		</div>
		
		<div class = "menu">
		
			<ol>
			
				<li style="width: 200px;"><a href = "index.php">Strona główna</a></li>
				<li><a href = "koszyk.php">Kosz2</a></li>
				<li><a href = "index.php">Wyloguj</a></li>
	
				<div style = "clear: both;"></div>
			
			</ol>
		
		</div>
		
		<div class = "container">
		

			<div class = "content">

				<h2>Detale zamówienia<h2>

				<div class = "contentBox" style="margin-left: 20%;">
				
<table style="font-size: 20px; margin-top: 10%; margin-left: 17%;padding: 0; width: 500px;">
<tr style="width: 200px;">
<th>Nazwa przedmiotu</th>
<th>Ilosc</th>
<th>Cena</th>
<th>Dodaj / Usuń</th>
</tr>		
 <?php foreach($buff as $i => $element){ ?>
 
	<tr>
		<td style="padding: 5px;"><?php echo $element['name']; ?></td>
		<td><?php echo $element['ilosc']; ?></td>
		<td><?php echo  number_format($element['price']*$element['ilosc']); ?></td>
		<td><a href = "dodajUsunKosz.php?num=1&iden=<?php echo $i; ?>">+</a>	/	<a href = "dodajUsunKosz.php?num=-1&iden=<?php echo $i; ?>">-</a></td>
	</tr>
 	
<?php } ?>	
</table>
 <form action="checkProductsAmount.php" method="post">
<?php $_SESSION['zamowienie']=false; ?>
<div id = "errorId" style="right: 28%; margin-top: 2%;">
	
<?php

	if(isset($_SESSION['errorZamowienie']))
	{ 
		echo $_SESSION['errorZamowienie'];
		unset($_SESSION['errorZamowienie']);
	}

?>

</div>
	<div style="margin-top: 20%; width: 300;">
	<input type="submit" value="Zamawiam" style="margin-left: 15%;">
	</div>
	</form>
	
	
	
	</div>
	
	
		</div>
	</body>
	</html>