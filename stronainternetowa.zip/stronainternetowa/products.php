
<?php 

	//$buff = array();
	session_start();
	
	$buff[] = array('name' => 0, 'price' => 0);
	
	require_once "connect.php";
	
	$polaczenie = @new mysqli($host, $db_user, $db_password, $db_name);
	

	
	if($polaczenie->connect_errno!=0)
	{
		echo "Error: ".$polaczenie->connect_errno;
		header('Location: kosz.php');
	}
	else{
		
		for($i = 1; $i < 10; $i++){
			
			$sql = sprintf("select name, price from products where id='%d'", $i);
			
			if($rezultat = @$polaczenie->query($sql)){
				
				$wiersz = $rezultat->fetch_assoc();
				$buff[$i]['name'] = $wiersz['name'];
				$buff[$i]['price'] = $wiersz['price'];
			
			}
		}
		$polaczenie->close();
	}
	$_SESSION['products'] = $buff;
	header('Location: index.php');
	print_r($buff);

?>