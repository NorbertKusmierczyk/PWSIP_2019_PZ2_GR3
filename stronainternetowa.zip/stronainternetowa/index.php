
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Roboto:400,500,700" rel="stylesheet">
</head>
<body>


<div class="nav">
<img src="logo.png" height="70px" width="200px" align="middle" alt="logofirmy">
<input type="text" id="wyszukiwarka" name="searchbox" placeholder="Wpisz fraze..">
<input type="image" src="lupa.png" height="37px" width="37px" align="center" alt="submit">
<input type="submit" class="button" value="Zaloguj" onclick="window.location='loginSide.php';">
<input type="submit" class="button" value="Zarejestruj" onclick="window.location='registerSide.php';">
<div class="navmenukomponenty">
 <ul>
  <li><a href="kartygraficzne.php">Karty Graficzne</a></li>
  <li><a href="procesory.php">Procesory</a></li>
  <li><a href="pamięci.php">Pamięci RAM</a></li>
  <li><a href="płyty.php">Płyty Główne</a></li>
  <li><a href="zasilacze.php">Zasilacze</a></li>
  <li><a href="obudowy.php">Obudowy</a></li>
  <li><a href="klawiatury.php">Klawiatury</a></li>
  <li><a href="myszki.php">Myszki</a></li>
  <li><a href="słuchawki.php">Słuchawki</a></li>
  <li><a href="monitory.php">Monitory</a></li>
  <li><a href="laptopy.php">Laptopy</a></li>
  <li><a href="telewizory.php">Telewizory</a></li>
  <li><a href="smartfony.php">Smartfony</a></li>

 </ul>
</div>
<div class="navinfo">
 <ul>
  <li><a href="javascript:alert('Logować i Rejestrować się można tylko i wyłącznie na Stronie Głównej!');">Informacje</a></li>
 </ul>
</div>
</div>
<div class="naslider">
<slider>
  <slide><p>Myszki Modecom</p></slide>
  <slide><p>Zasilacze Seasonic</p></slide>
  <slide><p>Obudowy Fractal Design</p></slide>
  <slide><p>Słuchawki AKG</p></slide>
 </slider>
</div>

<div class="napis">POLECAMY</div>

<div class="noweprodukty">
<img class="obrazek" src="1.jpg">
<img class="obrazek" src="41.jpg">
<img class="obrazek" src="112.jpg">
<img class="obrazek" src="186.jpg">
<img class="obrazek" src="172.jpg">
</div>

<div class="napis">WARTO SPOJRZEĆ NA</div>

<div class="noweprodukty">
<img class="obrazek" src="2.jpg">
<img class="obrazek" src="73.jpg">
<img class="obrazek" src="190.jpg">
<img class="obrazek" src="264.jpg">
<img class="obrazek" src="301.jpg">
</div>



<div class="footer">
	Preware.com to jeden z największych i najpopularniejszych sklepów komputerowych w Polsce. W szerokiej ofercie sklepu można znaleźć wysokiej klasy laptopy, komputery na każdą kieszeń, wydajne podzespoły komputerowe oraz urządzenia peryferyjne. Szeroka oferta urządzeń, akcesoriów i podzespołów umożliwia skonfigurowanie i zakup komputerów o optymalnej wydajności i atrakcyjnej cenie. W asortymencie sklepu nie brak również sprzętów dla graczy – to ergonomiczne i precyzyjne myszki i klawiatury, wysokiej klasy słuchawki, wydajne karty graficzne, nowoczesne procesory i komfortowe fotele gamingowe. Szeroka oferta produktów i ich bardzo duża dostępność to kwestie, które sprawiają, że zakupy są szybkie i wygodne, a na zamówione sprzęty i akcesoria komputerowe nie trzeba długo czekać.
</div>




</body>
</html>
