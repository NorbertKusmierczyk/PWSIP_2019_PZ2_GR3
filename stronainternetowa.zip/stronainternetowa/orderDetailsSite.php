﻿
<?php

	$buff = array();
	session_start();
	
	//unset($buff);
	//unset($_SESSION['buff']);
	//header('Location: index.php');
	//exit();
	if(!isset($_SESSION['koszButton']))
	{
		header('Location: index.php');
		exit();
	}
	 
	if(isset($_SESSION['buff']))
		$buff = $_SESSION['buff'];
	
	//if(!empty($_POST)){
		//$buff[] = array('id' => $_SESSION['idUser'], 'user' => $_SESSION['user'], 'imie' => 'kl', 'nazwisko' => 0, 'email' => 0, 'select' => 0,'kod' => 0, 'adres' => 0,'numerDomu' => 0,'name' => 'nam', 'price' => 0, 'ilosc' => $_SESSION['amount']);
	//}

	$_SESSION['buff'] = $buff;
	
	
?>


<!DOCTYPE HTML>

<html>

<head>

	<meta charset = "utf-8" />
	<title>PreWare.com</title>
	<!--<link rel = "stylesheet" href = "style.css">-->
	<link rel = "stylesheet" href = "loginSideCSS.css">
	<link rel = "icon" href = "C:\Users\groun\Desktop\icon.ico">
	<script type = "text/javascript" src = "jquery-3.3.1.min.js"></script>
	<script type = "text/javascript" src = "menu.js"></script>
	<script type = "text/javascript" src = "slid.js"></script>
	<script src='https://www.google.com/recaptcha/api.js'></script>
	<script type = "text/javascript">


	var list = ["18-400", "18-300", "00-001", "01-248", "45-040"];

		 function checkMiasto(){
			 
			 var kod = document.getElementById('kodPocztowy');
			 var sel = document.getElementById('miasto');
			  
			var val = sel.options[sel.selectedIndex].value;
			 
			 
			if(val == "Lomza") kod.value = list[0];
			else if(val == "Zambrow") kod.value = list[1];
			else if(val == "Warszawa") kod.value = list[2];
			else if(val == "Krakow") kod.value = list[3];
			else if(val == "Opole") kod.value = list[4];
			else kod.value = "";
			 
		}
	
	</script>
	
	<style>
	#button
	{
	width: 20%;
	margin-top: 2%;
	margin-left: -4%;
	padding: 10px;
	position: absolute;
	cursor: pointer;
	color: blue;
	border: none;
	background-color: #664f41;
	}
	input[type = submit]
	{
	width: 20%;
	margin-top: 2%;
	margin-left: 17%;
	padding: 10px;
	position: absolute;
	cursor: pointer;
	color: blue;
	border: none;
	background-color: #664f41;
	}
	
	</style>

</head>

<body>

	
	<div class = "logo">
		
			<div class = "header">
			
				<img src = "tek.jpg" style = "float: left;">
				<div class = "tytulLogo"><span style = "color: #7c0c0c;">Dead</span>Game</div>
				
			</div>
			
			<div class = "zaloguj">
			
			<a href = "#"></a>
			</div>
			
		
		</div>
		
		<div class = "menu">
		
			<ol>
			
				<li><a href = "index.php">Main Page</a></li>
				<li>General Information
				
					<ul>
					
						<li>Class</li>
						<li>About Atrea</li>
						<li>Gallery</li>
						<li>Forum</li>
					
					</ul>
				
				</li>
				<li><a href = "staff.html">About Staff</a></li>
				<li><a href = "https://www.animezone.pl/">Donation</a></li>
				<li><a href = "loginSide.php">Zaloguj</a></li>
				<div style = "clear: both;"></div>
			
			</ol>
		
		</div>
		
		<div class = "container">
		

			<div class = "content">

				<h2>SIGN UP<h2>

				<div class = "contentBox">
				
				 <form  action="CardTest.php" method="post">
				

				
				<p>Imie*</p>
				<input type = "text" name = "imie"/>
				
<div id = "errorId">
	
<?php

	if(isset($_SESSION['errorImie']))
	{ 
		echo $_SESSION['errorImie'];
		unset($_SESSION['errorImie']);
	}

?>

</div>

				<p>Nazwisko*</p>
				<input type = "text" name = "nazwisko"/>
				
<div id = "errorId" style="top: 24%;">
	
<?php

	if(isset($_SESSION['errorNazwisko']))
	{ 
		echo $_SESSION['errorNazwisko'];
		unset($_SESSION['errorNazwisko']);
	}

?>

</div>
		
				
				<p>E-mail*</p>
				<input type = "text" name = "email"/>
				
<div id = "errorId" style="top: 34.5%;">
	
<?php

	if(isset($_SESSION['errorEmail']))
	{ 
		echo $_SESSION['errorEmail'];
		unset($_SESSION['errorEmail']);
	}

?>
</div>			
				<br />
				<div style="float:left;">
				<p>Miasto*</p>
				<select id = "miasto" name="select" onchange="checkMiasto()" style="width: 180px; height: 30px; float:left;">
				<option selected ></option>
				<option value="Lomza" >Łomża</option>
				<option value="Zambrow" >Zambrów</option>
				<option value="Warszawa">Warszawa</option>
				<option value="Krakow" >Kraków</option>
				<option value="Opole">Opole</option>
				</select>
				</div>
				<div style="float:right; width: 95px;">
				<p style="height: 13px;">Kod pocztowy</p>
				<input id = "kodPocztowy" type = "text" name = "kodPocztowy" readonly="true"/>
				</div>
				<div style="clear: both;">
				</div>
				

				<div style="float:left;">
				<p style = "height: 13px;">Adres*</p>
				<input type = "text" name = "adres"/>
				</div>
				<div style="float:right; width: 95px;">
				<p style="height: 13px;">Numer domu*</p>
				<input type = "text" name = "numerDomu"/>
				</div>
				<div style="clear: both;">
				</div>
	
<div id = "errorId" style="top: 45%;">
	
<?php

	if(isset($_SESSION['errorSelect']))
	{ 
		echo $_SESSION['errorSelect'];
		unset($_SESSION['errorSelect']);
	}

?>

</div>	
	
<div id = "errorId" style="top: 54.8%;">
	
<?php

	if(isset($_SESSION['errorAdres']))
	{ 
		echo $_SESSION['errorAdres'];
		unset($_SESSION['errorAdres']);
	}

?>

</div>			
				
				
				<br /><br />
				<label style="font-size: 19px; "><input style = "height:14px;" type = "checkbox" name = "regulamin">Regulamin</label>
				


<div id = "errorId" style="top: 63%;">
	
<?php

	if(isset($_SESSION['errorRegulamin']))
	{ 
		echo $_SESSION['errorRegulamin'];
		unset($_SESSION['errorRegulamin']);
	}

?>

</div>
				<br /><br />
				
				 
				<br />
				<input id="button" name="backCard" type="submit" value="Wróć" />
				<input type="submit" value="Zamawiam" />
				
				</form>
				<br></br>
				
				
				</div>
					
		
			</div>
	
	
	</div>


</body>


</body>

</html>