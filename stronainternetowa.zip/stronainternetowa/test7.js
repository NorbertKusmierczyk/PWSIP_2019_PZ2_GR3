var images = ["137.jpg","138.jpg","139.jpg","140.jpg","141.jpg","142.jpg","143.jpg","144.jpg","145.jpg","146.jpg","147.jpg","148.jpg","149.jpg","150.jpg","151.jpg","152.jpg","153.jpg","154.jpg","155.jpg","156.jpg","157.jpg","158.jpg","159.jpg","160.jpg","161.jpg"];

function list(){
	
	var div = "";
	
	for(var i=0; i<25; i++){
		
		div += '<div style="margin:20px 0px 0px 0px; height: 240px; color: red; position:relative;"><div style="position: absolute; top:1%; left: 2%;"><img width="200"; height="200"; src="'+images[i]+'"/></div><div style="position: absolute; left:45%; top:40%"><a href = "#">produkt</a></div></div>';
		
		
	}
	document.getElementById("banerprom").innerHTML = div;
}


window.onload = list;