var images = ["184.jpg","185.jpg","186.jpg","187.jpg","188.jpg","189.jpg","190.jpg","191.jpg","192.jpg","193.jpg","194.jpg","195.jpg","196.jpg","197.jpg","198.jpg","199.jpg","200.jpg","201.jpg","202.jpg","203.jpg","204.jpeg","205.jpg","206.jpg","207.jpg"];

function list(){
	
	var div = "";
	
	for(var i=0; i<24; i++){
		
		div += '<div style="margin:20px 0px 0px 0px; height: 240px; color: red; position:relative;"><div style="position: absolute; top:1%; left: 2%;"><img width="200"; height="200"; src="'+images[i]+'"/></div><div style="position: absolute; left:45%; top:40%"><a href = "#">produkty</a></div></div>';
		
		
	}
	document.getElementById("banerprom").innerHTML = div;
}


window.onload = list;