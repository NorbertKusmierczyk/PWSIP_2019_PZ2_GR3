
﻿
<?php
	
	$buff = array();
	session_start();
	 
	 if(!isset($_SESSION['dostawaIzaplata']))
	 {
		 header('Location: index.php');
		 exit();
	 }
	 unset($_SESSION['dostawaIzaplata']);
	if(isset($_SESSION['buff']))
		$buff = $_SESSION['buff'];
	
	
	if(!empty($_POST)){
		$buff[] = array('id' => $_GET['id'], 'user' => $_SESSION['user'], 'imie' => $_SESSION['imie'], 'nazwisko' => $_SESSION['nazwisko'], 'email' => $_SESSION['email'], 'name' => $_SESSION['user'], 'price' => 0, 'ilosc' => $_SESSION['amount']);
	}

	$_SESSION['buff'] = $buff;
	
	$_SESSION['type'] = '';

?>

<!DOCTYPE HTML>

<html>

<head>

	<meta charset = "utf-8" />
	<title>PreWare.com</title>
	<link rel = "stylesheet" href = "style.css">
	<link rel = "icon" href = "C:\Users\groun\Desktop\icon.ico">
	<script type = "text/javascript" src = "jquery-3.3.1.min.js"></script>
	<script type = "text/javascript" src = "menu.js"></script>
	<script type = "text/javascript" src = "slid.js"></script>
	<style>
	table, th, td {
		color: white;
		border: 1px solid white;
	}
	#button
	{
	width: 20%;
	margin-top: 2%;
	margin-left: -4%;
	padding: 10px;
	position: absolute;
	cursor: pointer;
	color: blue;
	border: none;
	background-color: #664f41;
	}
	input[type = submit]
	{
	width: 20%;
	margin-top: 2%;
	margin-left: 17%;
	padding: 10px;
	position: absolute;
	cursor: pointer;
	color: blue;
	border: none;
	background-color: #664f41;
	}
</style>

</head>

<body>

	
	<div class = "logo">
		
			<div class = "header">
			
				<img src = "tek.jpg" style = "float: left;">
				<div class = "tytulLogo"><span style = "color: #7c0c0c;">Dead</span>Game</div>
				
			</div>
			
		
	</div>
			
		
		</div>
		
		<div class = "menu">
		
			<ol>
			
				<li><a href = "index2.php">Strona Główna</a></li>
				<li>Kontakt
				
					<ul>
					
						<li>
						<li>8:00-21:00 w dni robocze:
						    Numer Telefonu: 123123</li>
						</li>
						<li class = "num">Napisz wiadomość</li>
					
					</ul>
				
				</li>
				<li><a href = "kosz.php">Kosz</a></li>
				<li><a href = "logout.php">Wyloguj</a></li>
	
				<div style = "clear: both;"></div>
			
			</ol>
		
		</div>
		
		<div class = "container">

		    <div class = "container2"></div>
		

			<div class = "content" style = "height: 600px; margin-top: 10%;">

				<h2>Detale zamówienia<h2>

<form action="zamowienie.php" method="post">				
				
<table style="font-size: 20px; margin-top: 10%; margin-left: 25%; padding: 5px; width: 500px;">
<tr style="width: 200px;">
<th>Rodzaj Dostawy</th>
<th>Za pobraniem</th>
<th>Przedpłata</th>
</tr>		
 
	<tr>
		<td style="padding: 5px;">FierceParcel</td>
		<td style="padding: 5px;"><input type="radio" name="dostawa" value="FierceParcel_Pobranie"></td>
		<td style="padding: 5px;"><input type="radio" name="dostawa" value="FierceParcel_Przedplata"></td>
	</tr>
	<tr>
		<td style="padding: 5px;">Kurier ADF</td>
		<td style="padding: 5px;"><input type="radio" name="dostawa" value="Kurier_Pobranie"></td>
		<td style="padding: 5px;"><input type="radio" name="dostawa"value="Kurier_Przedplata"></td>
	</tr>
	<tr>
		<td style="padding: 5px;">Polecony</td>
		<td style="padding: 5px;"><input type="radio" name="dostawa" value="Polecony_Pobranie"></td>
		<td style="padding: 5px;"><input type="radio" name="dostawa" value="Polecony_Przedplata"></td>
	</tr>
	<tr>
		<td style="padding: 5px;">Polecony Express</td>
		<td style="padding: 5px;"><input type="radio" name="dostawa" value="PoleconyEx_Pobranie"></td>
		<td style="padding: 5px;"><input type="radio" name="dostawa" value="Polecony_Przedplata"></td>
	</tr>
</table>
<div style="margin-right: 32%">
<input id="button" name="backCard" type="submit" value="Wróć" />
<input type="submit" value="Zamawiam"/>
</div>
</form>
</div>
</div>
</body>
</html>