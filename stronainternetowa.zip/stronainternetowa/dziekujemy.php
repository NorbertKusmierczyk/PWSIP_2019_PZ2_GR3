<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="style.css">
<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,700" rel="stylesheet"> 
</head>
<body>
	<div class="napis">Dziekujemy za zakupy!</div>
	<div class="napis2"><a href="index.php">Powrot na strone glowna</a></div>

</body>
</html>