## Medusa
A JavaFX library for Gauges. The main focus of this project is to provide Gauges that can be configured in multiple ways.

Donations are welcome at [Paypal](https://paypal.me/hans0l0)

## Overview
![Overview](https://github.com/HanSolo/Medusa/blob/master/Overview.png?raw=true)
